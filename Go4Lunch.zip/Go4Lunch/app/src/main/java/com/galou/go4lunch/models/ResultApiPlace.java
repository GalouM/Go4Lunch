package com.galou.go4lunch.models;

import com.google.android.libraries.places.api.internal.impl.net.pablo.PlaceResult;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResultApiPlace {

    @SerializedName("geometry")
    @Expose
    private PlaceResult.Geometry geometry;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("place_id")
    @Expose
    private String placeId;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("utc_offset")
    @Expose
    private Integer utcOffset;
    @SerializedName("vicinity")
    @Expose
    private String vicinity;
    @SerializedName("website")
    @Expose
    private String website;
    @SerializedName("international_phone_number")
    @Expose
    private String phoneNumber;
    @SerializedName("opening_hours")
    @Expose
    private OpeningHoursApiPlace openingHours;
    @SerializedName("photos")
    @Expose
    private List<PhotoApiPlace> photos;


    public PlaceResult.Geometry getGeometry() {
        return geometry;
    }

    public void setGeometry(PlaceResult.Geometry geometry) {
        this.geometry = geometry;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }


    public Integer getUtcOffset() {
        return utcOffset;
    }

    public void setUtcOffset(Integer utcOffset) {
        this.utcOffset = utcOffset;
    }

    public String getVicinity() {
        return vicinity;
    }

    public void setVicinity(String vicinity) {
        this.vicinity = vicinity;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }


    public OpeningHoursApiPlace getOpeningHours() {
        return openingHours;
    }

    public void setOpeningHours(OpeningHoursApiPlace openingHours) {
        this.openingHours = openingHours;
    }

    public List<PhotoApiPlace> getPhotos() {
        return photos;
    }

    public void setPhotos(List<PhotoApiPlace> photos) {
        this.photos = photos;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}