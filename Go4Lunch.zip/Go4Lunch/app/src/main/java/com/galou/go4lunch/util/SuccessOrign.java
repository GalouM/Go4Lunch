package com.galou.go4lunch.util;

/**
 * Created by galou on 2019-04-25
 */
public enum SuccessOrign {
    UPDATE_USER,
    DELETE_USER,
    UPDATE_PHOTO,
    UPDATE_RESTAURANT_PICKED,
    UPDATE_RESTAURANT_LIKED,
    REMOVE_RESTAURANT_PICKED,
    REMOVE_RESTAURANT_LIKED
}
