package com.galou.go4lunch.workmates;

import com.galou.go4lunch.models.User;

import java.util.List;

/**
 * Created by galou on 2019-04-30
 */
public interface WorkmateContract {
    void showUsers(List<User> users);
    void displayRestaurantDetail();
}
