package com.galou.go4lunch.settings;

/**
 * Created by galou on 2019-04-25
 */
public interface SettingsContract {

    void deleteAccountAndGoBackToAuth();
    void openConfirmationDialog();
}
