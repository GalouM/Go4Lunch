package com.galou.go4lunch.base;

import android.view.View;

/**
 * Created by galou on 2019-04-25
 */
public interface ButtonActionListener {
    void onClick(View view);
}
